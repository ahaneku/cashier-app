package aurelienribon.slidinglayout;

/**
 * @author Aurelien Ribon | http://www.aurelienribon.com/
 */
public enum SLSide {
	TOP, BOTTOM, LEFT, RIGHT
}
